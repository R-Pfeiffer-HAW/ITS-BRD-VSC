#ifndef AUSGABEDISPLAY_H
#define AUSGABEDISPLAY_H

void updateDisplay(double winkel, double geschw) ;

#endif