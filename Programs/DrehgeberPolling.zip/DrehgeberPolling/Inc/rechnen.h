#ifndef RECHNEN_H
#define RECHNEN_H




void rechnen(void);

#endif