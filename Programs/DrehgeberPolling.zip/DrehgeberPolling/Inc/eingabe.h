

#ifndef EINGABE_H
#define EINGABE_H

void input_signal(void);


#endif 