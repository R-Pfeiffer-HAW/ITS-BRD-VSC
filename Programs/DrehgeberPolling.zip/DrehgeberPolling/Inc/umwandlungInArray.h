#ifndef UMWANDLUNGINARRAY_H
#define UMWANDLUNGINARRAY_H

// --- Für die Ausgabe der zwei Werte ---
void doubleToCharArray(double value, char *out);

// Bei jedem durchlauf des Superloops wird eine Stelle des Arrays ausgegeben
void arrayAusgabe(char* array, int position, int zeile);


#endif