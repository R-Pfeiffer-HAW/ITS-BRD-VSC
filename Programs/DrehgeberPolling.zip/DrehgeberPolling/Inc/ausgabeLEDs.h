
#ifndef AUSGABELEDS_H
#define AUSGABELEDS_H


void toggle_LEDs(void);




#endif 