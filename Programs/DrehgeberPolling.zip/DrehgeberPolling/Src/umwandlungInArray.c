#include "umwandlungInArray.h"
#include <stdio.h>
#include "lcd.h"



void doubleToCharArray(double value, char *out) {
    int s = 0;

    // 1. Minuszeichen verarbeiten und s erhöhen
    if(value < 0) {
        out[s++] = '-';
        value = -value;
    }
    // Ganzzahl-Teil
    int ganz = (int)value;

    // eine Nachkommastelle 
    double frac = value - (double)ganz;
    int nach = (int)(frac * 10);

    int t = 0;
    char tmp[12];
    
    // 2. Ganzzahl-Teil korrekt konvertieren
    if(ganz == 0){
        tmp[t++] = '0';
    }else{
        while (ganz > 0){
        // KORREKTUR: Letzte Ziffer von 'ganz' ermitteln und speichern.
        tmp[t++] = '0' + (ganz % 10); 
        ganz = ganz / 10;
        }
    }
    
    // 3. Ganzzahl-Teil rückwärts kopieren (Vorzeichen ist bereits in 'out')
    while(t > 0){
        out[s++] = tmp[--t];
    }
    
    // 4. Dezimalpunkt hinzufügen
    out[s++]= '.';
    
    // 5. Nachkommastelle hinzufügen
    // Das (nach % 10) ist unnötig, aber funktional nicht schädlich.
    out[s++]= '0' + nach;
    out[s] = '\0';
}

//Bei jedem durchlauf des Superloops wird eine Stelle des Arrays ausgegeben
void arrayAusgabe(char* array, int position, int zeile){
    // ... (Diese Funktion ist korrekt für die zeichenweise Ausgabe)
    if(array[position] == '\0'){
        return;
    }
    char buf[2];
    buf[0] = array[position];
    buf[1] = '\0';

    lcdGotoXY(18 + position, zeile);
    lcdPrintS(buf);
}