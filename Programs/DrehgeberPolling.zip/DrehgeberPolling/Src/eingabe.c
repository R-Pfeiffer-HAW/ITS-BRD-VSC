
#include "eingabe.h"
#include "stm32f429xx.h"
#include <stdbool.h>



#define IDR_MASK_PIN_0 (0x01U << (0))
#define IDR_MASK_PIN_1 (0x01U << (1))


bool givePinA(void)
{                   
    if (IDR_MASK_PIN_0 == (GPIOA->IDR & IDR_MASK_PIN_0)) {
        return true;
    } else {
        return false;
    
    } 
 
}
bool givePinB(void)
{
    if (IDR_MASK_PIN_1 == (GPIOA->IDR & IDR_MASK_PIN_1) ) {
        return true;
    } else {
        return false;
    }
}


void input_signal(void)
{       
     bool A = givePinA();
     bool B = givePinB();

    if (A && B) {
        // Both signals high 
        // phase c 
        // Rechnenphase          
    } else if (A && !B) {
        // A high, B low
        // phase b
    } else if (!A && B) {
        // A low, B high
        // phase d

    }else if (!A && !B) {
        // Both signals low
        // phase a
    } 
    else {
        // Both signals low
        // error
    }




    // Polling
    
}




    // Funktion zur Verarbeitung von Eingabesignalen
   