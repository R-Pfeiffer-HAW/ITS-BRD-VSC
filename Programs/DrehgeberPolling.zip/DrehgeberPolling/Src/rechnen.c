

#include "rechnen.h"


void rechnen(void) {

    
    // Implementierung der Rechenoperationen
}   