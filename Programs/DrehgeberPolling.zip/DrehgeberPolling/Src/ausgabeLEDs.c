


#include "ausgabeLEDs.h"
void toggle_LEDs(void) {
    // Implementierung der Ausgabefunktion für die LEDs
}   



