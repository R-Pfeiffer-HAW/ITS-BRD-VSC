#include "display_update.h"
#include "lcd.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#define SIZE 10
#define VALUE_MAX_LEN SIZE

static char arrayWinkel[VALUE_MAX_LEN];
static char arrayGeschw[VALUE_MAX_LEN];

static char lastArrayWinkel[VALUE_MAX_LEN];
static char lastArrayGeschw[VALUE_MAX_LEN];

static int pos = 0;  // Index des auszuwertenden Zeichens
void updateDisplay(double winkel, double geschw)
{
    // Neue Strings generieren (immer terminieren!)
    snprintf(arrayWinkel, sizeof(arrayWinkel), "%.2f", winkel);
    snprintf(arrayGeschw, sizeof(arrayGeschw), "%.2f", geschw);

    // Sicherheitsmaßnahme: pos darf Strings nicht überlaufen
    int lenW = strlen(arrayWinkel);
    int lenG = strlen(arrayGeschw);

    if (pos >= lenW && pos >= lenG) 
    {
        pos = 0;
        return;
    }
    char out[2] = {0};  

    // --- WINKEL ZEICHENWEISE AKTUALISIEREN ---
    if (pos < lenW && arrayWinkel[pos] != lastArrayWinkel[pos])
    {
        lcdGotoXY(18 + pos, 2);    // X abhängig von pos
        out[0] = arrayWinkel[pos]; // Zeichen übernehmen
        lcdPrintS(out);
        lastArrayWinkel[pos] = arrayWinkel[pos];
    }

    // --- GESCHWINDIGKEIT ZEICHENWEISE AKTUALISIEREN ---
    if (pos < lenG && arrayGeschw[pos] != lastArrayGeschw[pos])
    {
        lcdGotoXY(18 + pos, 5);    // X abhängig von pos
        out[0] = arrayGeschw[pos];
        lcdPrintS(out);
        lastArrayGeschw[pos] = arrayGeschw[pos];
    }
    pos++; // nächstes Zeichen beim nächsten Aufruf     
}
