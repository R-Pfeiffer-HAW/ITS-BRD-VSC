

#include "ausgabeDisplay.h"

void output_display(void) {
    // Implementierung der Ausgabefunktion für das Display
}