#ifndef AUSGABEDISPLAY_H
#define AUSGABEDISPLAY_H

void output_display(void);

#endif