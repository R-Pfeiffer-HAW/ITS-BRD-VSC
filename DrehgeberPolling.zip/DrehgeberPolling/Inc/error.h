/** 
* @file error.H
* @author Esmat Rabaki, Raphael Pfeiffer
* @brief hier wird der Fehlerzustand zurückgesetzt 
*/

#ifndef ERROR_H
#define ERROR_H


/**
*@brief hier werden alle veriablen zurückgesetzt
*/
void fehlerZuruecksetzen(void);

#endif